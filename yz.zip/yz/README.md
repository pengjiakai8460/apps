###目录

1.通用文件
- /YZApiProtocol.php
- /YZHttpClient.php

2.签名调用
- /SignDemo.php
- /lib/YZSignClient.php
*此方式将在2017年10月31日后废弃不再支持，请尽快换用免签名调用

3.免签名调用
- /TokenDemo.php
- /YZTokenClient.php

4.获取token
- GetTokenDemo.php
- YZGetTokenClient.php
支持获取自用型、工具型、平台型三种类型的token获取

5.开发指南
https://www.youzanyun.com/docs

6.具体接口文档列表
https://www.youzanyun.com/apilist


###注意

1.PHP版本：>= 5.3

2.涉及上传图片的接口仅支持post，建议使用post调用接口

2017.06.22